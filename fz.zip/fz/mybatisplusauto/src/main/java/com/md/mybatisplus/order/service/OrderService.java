package com.md.mybatisplus.order.service;

import com.md.mybatisplus.order.entity.Order;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author md
 * @since 2021-07-26
 */
public interface OrderService extends IService<Order> {

}
