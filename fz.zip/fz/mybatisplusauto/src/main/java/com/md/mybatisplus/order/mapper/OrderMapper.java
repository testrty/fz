package com.md.mybatisplus.order.mapper;

import com.md.mybatisplus.order.entity.Order;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author md
 * @since 2021-07-26
 */
public interface OrderMapper extends BaseMapper<Order> {

}
