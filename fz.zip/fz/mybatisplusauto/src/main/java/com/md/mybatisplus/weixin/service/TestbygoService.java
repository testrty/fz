package com.md.mybatisplus.weixin.service;

import com.md.mybatisplus.weixin.entity.Testbygo;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author md
 * @since 2021-07-19
 */
public interface TestbygoService extends IService<Testbygo> {

}
