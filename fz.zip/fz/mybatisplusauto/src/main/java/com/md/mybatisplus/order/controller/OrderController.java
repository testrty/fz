package com.md.mybatisplus.order.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author md
 * @since 2021-07-26
 */
@Controller
@RequestMapping("/order/order")
public class OrderController {

}

