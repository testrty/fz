package com.md.mybatisplus.orderdetails.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author md
 * @since 2021-07-26
 */
@Controller
@RequestMapping("/orderdetails/orderdetails")
public class OrderdetailsController {

}

