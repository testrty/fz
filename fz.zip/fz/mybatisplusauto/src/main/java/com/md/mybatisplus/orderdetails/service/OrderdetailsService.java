package com.md.mybatisplus.orderdetails.service;

import com.md.mybatisplus.orderdetails.entity.Orderdetails;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author md
 * @since 2021-07-26
 */
public interface OrderdetailsService extends IService<Orderdetails> {

}
