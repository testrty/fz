package com.md.mybatisplus.weixin.mapper;

import com.md.mybatisplus.weixin.entity.Testbygo;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author md
 * @since 2021-07-19
 */
public interface TestbygoMapper extends BaseMapper<Testbygo> {

}
