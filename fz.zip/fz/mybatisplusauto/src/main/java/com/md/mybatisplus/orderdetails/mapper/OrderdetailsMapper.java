package com.md.mybatisplus.orderdetails.mapper;

import com.md.mybatisplus.orderdetails.entity.Orderdetails;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author md
 * @since 2021-07-26
 */
public interface OrderdetailsMapper extends BaseMapper<Orderdetails> {

}
