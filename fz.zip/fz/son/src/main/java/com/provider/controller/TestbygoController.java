package com.provider.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author md
 * @since 2021-06-15
 */
@Controller
@RequestMapping("/com.provider/testbygo")
public class TestbygoController {

}

