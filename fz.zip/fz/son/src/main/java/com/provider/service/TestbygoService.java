package com.provider.service;

import com.provider.entity.Testbygo;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author md
 * @since 2021-06-15
 */
public interface TestbygoService extends IService<Testbygo> {

}
