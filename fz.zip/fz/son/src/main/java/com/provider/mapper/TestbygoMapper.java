package com.provider.mapper;

import com.provider.entity.Testbygo;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author md
 * @since 2021-06-15
 */
public interface TestbygoMapper extends BaseMapper<Testbygo> {

}
