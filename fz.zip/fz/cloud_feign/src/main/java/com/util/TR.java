package com.util;


public class TR {
    public static void main(String[] args) {

//        String  platform="9";
//        String  modem="8";
//        String  compileCommand="4";
//        String  project="3";
//
//        System.out.println("1111"+" "+"你会");
//
//        String [] cmd={"66","9","666"};
//        System.out.println(cmd.toString());



//        String [] cmd={"/bin/sh","-c","cd /home/phil/genius/ud710 && ./"+softWare+".sh"+" "+platform+"_"+modem+""+ project+""+ compileCommand};
//        System.out.println(cmd.toString());
//        System.out.println(softWare+" nbsp "+platform +" nbsp "+" "+modem+" "+project+"   "+compileCommand);

    }
}
