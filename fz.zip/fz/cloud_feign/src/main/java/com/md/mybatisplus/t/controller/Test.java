package com.md.mybatisplus.t.controller;

public class Test {
    public static void main(String[] args) {
       
    }
}
