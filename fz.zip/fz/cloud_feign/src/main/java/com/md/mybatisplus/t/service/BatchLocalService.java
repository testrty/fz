//package com.md.mybatisplus.t.service;
//
//
//import com.baomidou.mybatisplus.service.IService;
//import com.md.mybatisplus.t.entity.LocalTest;
//
//
//public interface BatchLocalService  extends IService<LocalTest> {
//}
