package com.md.mybatisplus.t.Utils;

import java.util.UUID;

/**
 *
 *
 */

public class ThreadPoolConfig {
    public static void main(String[] args) {
        String uuid= String.valueOf(UUID.randomUUID());
        System.out.println(uuid);

    }



}

