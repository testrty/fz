//package com.md.mybatisplus.t.service.impl;
//
//import com.baomidou.mybatisplus.mapper.Wrapper;
//import com.baomidou.mybatisplus.plugins.Page;
//import com.baomidou.mybatisplus.service.impl.ServiceImpl;
//import com.md.mybatisplus.t.entity.LocalTest;
//import com.md.mybatisplus.t.mapper.LocalTestMapper;
//import com.md.mybatisplus.t.service.BatchLocalService;
//import org.springframework.stereotype.Service;
//
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.List;
//import java.util.Map;
//@Service
//public class BatchLocalServiceImpl  extends ServiceImpl<LocalTestMapper, LocalTest>implements BatchLocalService {
//
//}