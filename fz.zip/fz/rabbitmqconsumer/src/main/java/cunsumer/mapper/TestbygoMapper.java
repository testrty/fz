package cunsumer.mapper;

import  cunsumer.entity.Testbygo;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author md
 * @since 2021-06-15
 */
@Mapper
public interface TestbygoMapper extends BaseMapper<Testbygo> {

}
